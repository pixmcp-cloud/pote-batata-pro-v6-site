// Generated from the actual bundled catalogs, never client-supplied model flags.
// The Free tier persists at most one ORIGINAL record per group and scope (base/extra).
export const FREE_LIMITED_GROUPS=Object.freeze({
 recipes:1,ingredients:1,orders:1,clients:1,suppliers:1,expenses:1,
 purchases:1,losses:1,prepBatches:1,beverages:1,addons:1,combos:1
});
export const BASE_FREE_GROUPS=Object.freeze([
 'recipes','ingredients','clients','suppliers','expenses','beverages','addons','combos'
]);
export const FREE_TEMPLATE_IDS=Object.freeze({
 batataria: {
  recipes: ["r01", "r02", "r03", "r04", "r05", "r06", "r07", "r08", "r09", "r10", "r11", "r12", "r13", "r14", "r15", "r16", "r17", "r18", "r19", "r20", "r21", "r22", "r23", "r24", "r25", "r26"],
  ingredients: ["batata", "leite", "manteiga", "sal", "frango", "calabresa", "bacon", "carne", "patinho", "costela", "seca", "camarao", "blumenau", "requeijao", "mussarela", "cheddar", "parmesao", "gorgonzola", "creme", "tomate", "cebola", "milho", "brocolis", "palmito", "azeitona", "pimentao", "champignon", "batata_palha", "verde", "bbq", "presunto", "salsicha", "oregano", "batata_doce", "condensado", "leite_po", "avelas", "cacau", "granulado", "chocolate_escuro", "chocolate_branco", "morango", "emb_pote", "emb_talher", "emb_sacola"],
  expenses: ["ex-gas", "ex-luz", "ex-agua", "ex-pessoal", "ex-gasolina", "ex-frete"],
  beverages: ["preset-agua-sem-gas", "preset-agua-com-gas", "preset-guarana-lata", "preset-cola-lata", "preset-laranja-lata", "preset-guarana-600", "preset-cola-600", "preset-laranja-600", "preset-guarana-zero-600", "preset-cola-zero-600", "preset-laranja-zero-600"],
  combos: ["starter-potato-soda"],
 },
 pizzaria: {
  recipes: ["pz-01", "pz-02", "pz-03", "pz-04", "pz-05", "pz-06", "pz-07", "pz-08", "pz-09", "pz-10", "pz-11", "pz-12", "pz-13", "pz-14", "pz-15", "pz-16", "pz-17", "pz-18", "pz-19", "pz-20", "pz-21", "pz-22", "pz-23", "pz-24", "pz-25", "pz-26", "pz-27", "pz-28", "pz-29", "pz-30"],
  ingredients: ["pz-in-massa-para-pizza-aberta", "pz-in-molho-de-tomate-temperado", "pz-in-mucarela", "pz-in-calabresa-fatiada", "pz-in-cebola-roxa", "pz-in-frango-desfiado", "pz-in-requeijao-cremoso", "pz-in-milho-verde", "pz-in-tomate-em-rodelas", "pz-in-manjericao-fresco", "pz-in-azeite-de-oliva", "pz-in-mucarela-adicional", "pz-in-oregano", "pz-in-presunto", "pz-in-ovo-cozido", "pz-in-ervilha", "pz-in-azeitona-preta", "pz-in-provolone", "pz-in-gorgonzola", "pz-in-parmesao", "pz-in-pepperoni", "pz-in-alho-fresco", "pz-in-lombo-canadense", "pz-in-bacon", "pz-in-atum-escorrido", "pz-in-palmito", "pz-in-abobrinha", "pz-in-berinjela", "pz-in-pimentao", "pz-in-champignon", "pz-in-brocolis", "pz-in-rucula", "pz-in-tomate-seco", "pz-in-pimenta-dedo-de-moca", "pz-in-queijo-prato", "pz-in-camarao-limpo", "pz-in-carne-seca-dessalgada", "pz-in-molho-barbecue", "pz-in-chocolate-ao-leite", "pz-in-creme-de-leite", "pz-in-morango", "pz-in-banana", "pz-in-canela-em-po", "pz-in-leite-condensado", "pz-in-goiabada"],
 },
 hamburgueria: {
  recipes: ["hb-01", "hb-02", "hb-03", "hb-04", "hb-05", "hb-06", "hb-07", "hb-08", "hb-09", "hb-10", "hb-11", "hb-12", "hb-13", "hb-14", "hb-15", "hb-16", "hb-17", "hb-18", "hb-19", "hb-20", "hb-21", "hb-22", "hb-23", "hb-24", "hb-25", "hb-26", "hb-27", "hb-28", "hb-29", "hb-30"],
  ingredients: ["hb-in-pao-para-hamburguer", "hb-in-hamburguer-bovino", "hb-in-sal", "hb-in-queijo-cheddar", "hb-in-picles", "hb-in-ketchup", "hb-in-mostarda", "hb-in-queijo-prato", "hb-in-alface", "hb-in-tomate", "hb-in-maionese", "hb-in-bacon", "hb-in-ovo", "hb-in-presunto", "hb-in-milho-verde", "hb-in-calabresa-fatiada", "hb-in-cebola", "hb-in-molho-especial", "hb-in-cheddar-cremoso", "hb-in-cebola-crispy", "hb-in-molho-barbecue", "hb-in-cebola-caramelizada", "hb-in-queijo-gorgonzola", "hb-in-rucula", "hb-in-provolone", "hb-in-pimenta-jalapeno", "hb-in-molho-picante", "hb-in-hamburguer-de-picanha", "hb-in-costela-bovina-desfiada", "hb-in-carne-suina-desfiada", "hb-in-coleslaw", "hb-in-file-de-frango-empanado", "hb-in-file-de-frango-grelhado", "hb-in-hamburguer-de-grao-de-bico", "hb-in-hamburguer-de-cogumelos", "hb-in-mucarela-de-bufala", "hb-in-manjericao-fresco", "hb-in-molho-pesto", "hb-in-abacaxi-grelhado", "hb-in-champignon", "hb-in-maionese-trufada"],
 },
 hotdog: {
  recipes: ["hd-01", "hd-02", "hd-03", "hd-04", "hd-05", "hd-06", "hd-07", "hd-08", "hd-09", "hd-10", "hd-11", "hd-12", "hd-13", "hd-14", "hd-15", "hd-16", "hd-17", "hd-18", "hd-19", "hd-20"],
  ingredients: ["hd-in-pao-para-hot-dog", "hd-in-salsicha", "hd-in-molho-de-tomate", "hd-in-batata-palha", "hd-in-milho-verde", "hd-in-ervilha", "hd-in-mostarda", "hd-in-ketchup", "hd-in-pure-de-batata", "hd-in-vinagrete", "hd-in-maionese", "hd-in-mucarela", "hd-in-presunto", "hd-in-bacon", "hd-in-cheddar-cremoso", "hd-in-cebola-crispy", "hd-in-calabresa-fatiada", "hd-in-frango-desfiado", "hd-in-requeijao-cremoso", "hd-in-provolone", "hd-in-queijo-prato", "hd-in-molho-barbecue", "hd-in-cebola-caramelizada", "hd-in-molho-picante", "hd-in-pimenta-jalapeno", "hd-in-chucrute", "hd-in-ovo-de-codorna", "hd-in-salsicha-vegetal", "hd-in-salsicha-artesanal", "hd-in-queijo-cheddar", "hd-in-molho-especial"],
 },
 lancheria: {
  recipes: [],
  ingredients: [],
 },
 pastelaria: {
  recipes: ["ps-01", "ps-02", "ps-03", "ps-04", "ps-05", "ps-06", "ps-07", "ps-08", "ps-09", "ps-10", "ps-11", "ps-12", "ps-13", "ps-14", "ps-15", "ps-16", "ps-17", "ps-18", "ps-19", "ps-20", "ps-21", "ps-22", "ps-23", "ps-24", "ps-25", "ps-26", "ps-27", "ps-28", "ps-29", "ps-30", "ps-31", "ps-32", "ps-33", "ps-34", "ps-35", "ps-36", "ps-37", "ps-38", "ps-39", "ps-40", "ps-41", "ps-42", "ps-43", "ps-44", "ps-45", "ps-46", "ps-47", "ps-48", "ps-49", "ps-50"],
  ingredients: ["ps-in-massa-fresca-para-pastel", "ps-in-oleo-de-fritura-absorvido", "ps-in-carne-moida-cozida", "ps-in-cebola", "ps-in-tomate", "ps-in-cheiro-verde", "ps-in-mucarela", "ps-in-ovo-cozido", "ps-in-azeitona", "ps-in-cheddar-cremoso", "ps-in-bacon-frito-escorrido", "ps-in-carne-seca-dessalgada-cozida", "ps-in-requeijao-cremoso", "ps-in-abobora-cabotia-cozida", "ps-in-frango-cozido-e-desfiado", "ps-in-milho-verde-cozido", "ps-in-presunto", "ps-in-oregano", "ps-in-provolone", "ps-in-parmesao", "ps-in-calabresa-cozida-em-rodelas", "ps-in-palmito-cozido", "ps-in-molho-branco-espesso", "ps-in-brocolis-cozido-e-escorrido", "ps-in-escarola-refogada-e-escorrida", "ps-in-espinafre-cozido-e-escorrido", "ps-in-ricota", "ps-in-alho", "ps-in-manjericao", "ps-in-camarao-limpo-e-cozido", "ps-in-salsinha", "ps-in-azeite", "ps-in-atum-escorrido", "ps-in-bacalhau-dessalgado-cozido", "ps-in-estrogonofe-de-carne-frio-e-espesso", "ps-in-batata-palha", "ps-in-estrogonofe-de-frango-frio-e-espesso", "ps-in-chocolate-ao-leite", "ps-in-creme-de-leite", "ps-in-chocolate-branco", "ps-in-brigadeiro-firme", "ps-in-granulado-de-chocolate", "ps-in-beijinho-firme", "ps-in-coco-ralado", "ps-in-goiabada", "ps-in-queijo-minas", "ps-in-doce-de-leite-firme", "ps-in-banana-em-rodelas", "ps-in-acucar", "ps-in-canela-em-po", "ps-in-morango-higienizado-e-bem-seco"],
 },
});
export const quotaScope=universe=>['batataria','default','kitchen'].includes(String(universe))?'base':'extra';
export const isBundledTemplate=rec=>Boolean(rec&&
 (FREE_TEMPLATE_IDS[rec.universe]?.[rec.group]||[]).includes(String(rec.id)));
export const isFreeLimitedRecord=rec=>Boolean(rec&&
 (quotaScope(rec.universe)==='extra'?
  Object.prototype.hasOwnProperty.call(FREE_LIMITED_GROUPS,rec.group):
  BASE_FREE_GROUPS.includes(rec.group))&&!isBundledTemplate(rec));
export function modelRecordKey(rec){
 if(!isBundledTemplate(rec))return null;
 return 'model~'+rec.universe+'~'+rec.group+'~'+rec.id;
}
export function freeSlotKey(rec){
 if(!isFreeLimitedRecord(rec))return null;
 return 'free~'+quotaScope(rec.universe)+'~'+rec.group;
}
